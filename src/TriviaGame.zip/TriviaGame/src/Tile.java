
public class Tile {
	String color, questionType;
	
	public Tile(String cr, String quesType) {
		color = cr;
		questionType = quesType;
	}

}
