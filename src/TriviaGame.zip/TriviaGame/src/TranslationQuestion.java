
public class TranslationQuestion extends Question{
	public TranslationQuestion(String desc, String ans) {
		question = desc;
		answer = ans;
	}

}
