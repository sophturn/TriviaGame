import java.util.*;
import java.lang.reflect.Array;

public class TriviaGame {
	//Tile Array - board
	Scanner sc = new Scanner(System.in);
	Random rand = new Random();
	ArrayList<Question> easyQuestions;
	ArrayList<Question> mediumQuestions;
	ArrayList<Question> hardQuestions;
	ArrayList<Question> finalQuestions;
	Tile[][] board;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public void setQuestions() {}

}
