
public class VerbConjugationQuestion extends Question{
	
	public VerbConjugationQuestion(String desc, String ans) {
		answer = ans;
		question = desc;
	}

}
